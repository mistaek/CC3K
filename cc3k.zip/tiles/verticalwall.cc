#include "verticalwall.h"

VerticalWall::VerticalWall(int r, int c): Tile{r, c, 0, '|'}{}
