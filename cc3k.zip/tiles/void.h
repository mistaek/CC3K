#ifndef __void_h__
#define __void_h__
#include "../tile.h"

class Void: public Tile{
    public:
        Void(int r, int c);
};

#endif
