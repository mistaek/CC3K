#ifndef __verticalwall_h__
#define __verticalwall_h__
#include "../tile.h"

class VerticalWall: public Tile{
    public:
        VerticalWall(int r, int c);
};

#endif
