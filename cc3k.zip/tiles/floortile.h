#ifndef __floortile_h__
#define __floortile_h__
#include "../tile.h"

class FloorTile: public Tile{
    public:
        FloorTile(int r, int c);
};

#endif
