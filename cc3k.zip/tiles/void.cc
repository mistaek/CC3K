#include "void.h"

Void::Void(int r, int c):Tile{r, c, 0, ' '}{}
