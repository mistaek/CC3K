#ifndef __doorway_h__
#define __doorway_h__
#include "../tile.h"

class Doorway: public Tile{
    public:
        Doorway(int r, int c);

};

#endif