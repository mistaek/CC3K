#include "passage.h"

Passage::Passage(int r, int c): Tile{r, c, 1, '#'}{}
