#ifndef __passage_h__
#define __passage_h__
#include "../tile.h"

class Passage:public Tile{
    public:
        Passage(int r, int c);
};

#endif