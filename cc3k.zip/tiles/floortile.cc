#include "floortile.h"

FloorTile::FloorTile(int r, int c): Tile{r, c, 1, '.'}{}

