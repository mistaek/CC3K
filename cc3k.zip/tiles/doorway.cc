#include "doorway.h"

Doorway::Doorway(int r, int c): Tile{r, c, 1, '+'}{}
