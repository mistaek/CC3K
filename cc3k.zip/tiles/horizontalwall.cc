#include "../tile.h"
#include "horizontalwall.h"

HorizontalWall::HorizontalWall(int r, int c): Tile{r, c, 0, '-'}{}
