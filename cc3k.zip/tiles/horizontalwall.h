#ifndef __horizontal_wall_h__
#define __horizontal_wall_h__
#include "../tile.h"

class HorizontalWall : public Tile{
    public:
        HorizontalWall(int r, int c);
};

#endif
