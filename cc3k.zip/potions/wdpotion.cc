#include "wdpotion.h"

WDPotion::WDPotion(int r, int c): Potion{r, c, 0, 0, -5, "WD"}{}
