#include "rhpotion.h"

RHPotion::RHPotion(int r, int c): Potion{r, c, 10, 0, 0, "RH"}{}