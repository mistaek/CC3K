#include "wapotion.h"

WAPotion::WAPotion(int r, int c): Potion{r, c, 0, -5, 0, "WA"}{}
