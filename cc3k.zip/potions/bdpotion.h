#ifndef __bd_potion_h__
#define __bd_potion_h__
#include "../potion.h"

class BDPotion:public Potion{
    public: 
        BDPotion(int r, int c);

};

#endif