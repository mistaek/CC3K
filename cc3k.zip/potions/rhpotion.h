#ifndef __rh_potion_h__
#define __rh_potion_h__
#include "../potion.h"

class RHPotion : public Potion{
    public:
        RHPotion(int r, int c);
};

#endif
