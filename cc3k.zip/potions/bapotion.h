#ifndef __ba_potion_h__
#define __ba_potion_h__
#include "../potion.h"

class BAPotion:public Potion{
    public: 
        BAPotion(int r, int c);

};

#endif