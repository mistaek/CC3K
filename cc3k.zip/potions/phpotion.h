#ifndef __ph_potion_h__
#define __ph_potion_h__
#include "../potion.h"

class PHPotion : public Potion{
    public:
        PHPotion(int r, int c);
};

#endif
