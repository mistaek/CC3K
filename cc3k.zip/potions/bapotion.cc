#include "bapotion.h"
#include "../potion.h"
#include <string>

BAPotion::BAPotion(int r, int c): Potion{r, c, 0, 5, 0, "BA"}{}
