#include "phpotion.h"

PHPotion::PHPotion(int r, int c): Potion{r, c, -10, 0, 0, "PH"}{}