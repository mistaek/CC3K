#ifndef __wd_potion_h__
#define __wd_potion_h__
#include "../potion.h"

class WDPotion:public Potion{
    public: 
        WDPotion(int r, int c);

};

#endif