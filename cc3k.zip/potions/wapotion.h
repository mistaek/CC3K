#ifndef __wa_potion_h__
#define __wa_potion_h__
#include "../potion.h"

class WAPotion:public Potion{
    public: 
        WAPotion(int r, int c);

};

#endif