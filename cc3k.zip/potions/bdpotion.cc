#include "bdpotion.h"
#include "../potion.h"
BDPotion::BDPotion(int r, int c): Potion{r, c, 0, 0, 5, "BD"}{}
