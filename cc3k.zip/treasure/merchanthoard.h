#ifndef __merchant_hoard_h__
#define __merchant_hoard_h__
#include "../treasure.h"

class MerchantHoard: public Treasure{
    public:
        MerchantHoard(int r, int c);
};

#endif
