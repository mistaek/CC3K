#include "biggold.h"

BigGold::BigGold(int r, int c): Treasure{r, c, 2, 1, 0}{}
