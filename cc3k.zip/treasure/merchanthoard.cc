#include "merchanthoard.h"

MerchantHoard::MerchantHoard(int r, int c): Treasure{r, c, 4, 1, 0}{}
