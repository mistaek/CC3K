#ifndef __gold_small_h__
#define __gold_small_h__
#include "../treasure.h"

class SmallGold: public Treasure{
    public:
        SmallGold(int r, int c);
};

#endif
