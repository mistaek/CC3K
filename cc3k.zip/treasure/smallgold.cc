#include "smallgold.h"

SmallGold::SmallGold(int r, int c): Treasure{r, c, 1, 1, 0}{}
