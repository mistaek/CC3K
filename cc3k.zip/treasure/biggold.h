#ifndef __gold_big_h__
#define __gold_big_h__
#include "../treasure.h"

class BigGold: public Treasure{
    public:
        BigGold(int r, int c);
};

#endif
