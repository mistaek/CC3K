#include "vampire.h"

Vampire::Vampire(int r, int c): Enemy{r, c, 50, 25, 25, 1, 'V', EnemyType::Vampire}{}
