#ifndef __vampire_h__
#define __vampire_h__
#include "../enemy.h"

class Vampire : public Enemy{
    public:
        Vampire(int r, int c);
};

#endif
