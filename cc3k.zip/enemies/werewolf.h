#ifndef __werewolf_h__
#define __werewolf_h__
#include "../enemy.h"

class Werewolf: public Enemy{
    public:
        Werewolf(int r, int c);
};
#endif
