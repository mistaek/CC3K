#ifndef __goblin_h__
#define __goblin_h__
#include "../enemy.h"

class Goblin: public Enemy{
    public:
        Goblin(int r, int c);
};
#endif
