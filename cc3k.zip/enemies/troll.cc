#include "troll.h"

Troll::Troll(int r, int c): Enemy{r, c, 120, 25, 15, 1, 'T',EnemyType::Troll}{}
