#ifndef __troll_h__
#define __troll_h__
#include "../enemy.h"

class Troll: public Enemy{
    public:
        Troll(int r, int c);
};
#endif
