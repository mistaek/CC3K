#ifndef __phoenix_h__
#define __phoenix_h__
#include "../enemy.h"

class Phoenix: public Enemy{
    public:
        Phoenix(int r, int c);
};
#endif
