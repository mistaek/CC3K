#include "goblin.h"

Goblin::Goblin(int r, int c): Enemy{r, c, 70, 5, 10, 1,'N', EnemyType::Goblin}{}
