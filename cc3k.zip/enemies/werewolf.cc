#include "werewolf.h"

Werewolf::Werewolf(int r, int c): Enemy{r, c, 120, 30, 5, 1, 'W', EnemyType::Werewolf}{}
