#include "phoenix.h"

Phoenix::Phoenix(int r, int c): Enemy{r, c, 50, 35, 20, 1, 'X', EnemyType::Phoenix}{}
